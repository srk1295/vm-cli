#!/usr/bin/env python3 

from setuptools import setup, find_packages

setup(
    name='vm-cli',
    version='1.0',
    description='Package install Guest Application',
    long_description='This is a sample package that demonstrates how to use the include_package_data option in the setup.py file.',
    url='https://github.com/myusername/mypackage',
    author='Karthik Kumaar',
    author_email='karthik_kumaar_mahudeeswaran@baxter.com',
    license='MIT',
    packages = ['source'],
    #packages = find_packages(include=["source","source/scripts"]),
    include_package_data=True,
    #exe_prefix='/usr/bin',
    install_requires=[
        'cmd2',
        'pexpect',
    ],
    entry_points='''
        [console_scripts]
        vm-cli=source.cli:main
    ''',
)