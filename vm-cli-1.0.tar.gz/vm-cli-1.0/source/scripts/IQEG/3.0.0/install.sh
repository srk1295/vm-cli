#!/bin/bash
echo "installing IQEG....."
