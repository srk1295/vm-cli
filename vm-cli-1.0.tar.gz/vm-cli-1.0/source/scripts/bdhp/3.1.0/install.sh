/appliance/bin/setup-m8s-storage /dev/sdb
/appliance/bin/setup-db-storage /dev/sdc
/appliance/install_microk8s.sh --dns-servers "10.251.210.129,10.251.208.129"
/appliance/bin/change_metallb_ip
/appliance/install_database.sh --postgres
/appliance/pull_mdap_platform_charts.sh 3.1.0
mdap configure:postgres -n ns
mdapFqdn=$(hostname).stg.baxter.com
mdapVersion=3.1.0
mdap platform:install $mdapVersion -n ns --set "keycloak.countryOfDeployment=US" --set "pim.enabled=false" --set "tags.monitoring=true" --domain=$mdapFqdn --database=postgresql --set "global.customer.name=brdstg"

sleep 15
yq e '(.dependencies[] | select(.name == "mdap-language-library") | .version)="1.9.0"' -i /baxter-apps/charts/mdap/Chart.yaml
sed -i -e 's/version: .*/version: 1.9.0/' /baxter-apps/charts/mdap/charts/mdap-language-library/Chart.yaml
sed -i -e 's/appVersion: .*/appVersion: 1.9.0/' /baxter-apps/charts/mdap/charts/mdap-language-library/Chart.yaml
mdap upgrade "baxter-mdap-charts:3.1.0" -n ns
