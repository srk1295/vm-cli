# As root, run automatic set-up of attached database storage disk on 2nd device attached to SCSI disk controller
sudo lva setup-m8s-storage /dev/sdb --force

# IF VM IS HOSTED ON BAXTER NETWORK (SO GLENDALE SERVER FOR EXAMPLE), USE THIS. Otherwise change based on your hypervisor or laptop location.
sudo lva install-microk8s --dns-servers "10.251.210.129,10.251.208.129"

# Assign Metallb IP Address
sudo lva change-metallb-ip "$(ip addr | grep eth0 | grep inet | cut -d" " -f6 | cut -d"/" -f1)"

# As root, run automatic set-up of attached Postgres storage disk on 3rd device attached to SCSI disk controller
sudo lva setup-db-storage /dev/sdc postgres --force

# As root, run automatic set-up of attached backups storage disk on 4th device attached to SCSI disk controller
sudo lva setup-backups-storage /dev/sdd --force

lsblk

# NOTE that there is no need to label the node any more as this is done by lva setup-db-storage (given microk8s is already installed)

# Install PostgreSQL database on the appliance
sudo lva install-postgres --force

# Check if mongoDB is needed
read -p "Do you want to install MongoDB (yes/no):" md

if [[ "$md" == "yes" ]]; then

         # Label the node as being suitable for Redis (for Bed Device Gateway)
        lva label-node $(hostname) redis-bdg
        # Install MongoDB document-oriented database (and the MongoDB Operator)
        lva install-mongodb --yes
fi

# Install Baxter proxy cert
mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter1.crt -n ns
mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter2.crt -n ns
mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter3.crt -n ns



 # OPTIONAL STEP
 # Install the Neo4j Graph database if you plan to install a guest application that requires it. (e.g. ICNET)
#lva install-neo4j --yes

 # OPTIONAL STEP
 # Install the MySQL database (and operator) if you plan to install a guest application that requires it. (e.g. ICNET, DoseIQ, Guardian)
#lva install-mysql --yes

## Environment Variable: Fully Qualified Domain Name
 ##
 ## This is what you'll type into your browser (https://<fqdn>) to use the web UI.
 ## which is something.stg.baxter.com
#bdhpFqdn=$(hostname).stg.baxter.com
 ## Environment Variable: Version of DeviceBridge to install
 ##
bdhpVersion=4.1.7
 # Install DeviceBridge

 # Note: since we are deploying both Pump and Bed Verne, we configure the pump verne to list on port 8883
 # Further Note: we don't expect Novum pumps to use 8884 in production! This is just a quick setup thing.
 # Additionally: CPU requests for Pump Verne and Rabbit are being overridden to reduce the CPU required for
if [[ "$md" == "yes" ]]; then

        mdap platform:install 4.1.7 \
        -n ns \
        --domain=$bdhpFqdn \
        --database=postgres \
        --set 'tags.beds=true' \
        --set 'tags.cdr=true' \
        --set 'tags.mirth=true' \
        --set 'tags.pumps=true' \
        --set 'bdhp-vernemq-pumps.service.mqtts.port=8883' \
        --set 'tags.wa-vitals=false' \
        --set 'tags.manual-adt=true' \
        --set 'tags.monitoring=true' \
        --set 'clamav.enabled=true' \
        --set 'bdhp-ntpd.enabled=true' \
        --set 'linkerd.enabled=true' \
        --set 'smtp.host=relays.baxter.com,smtp.port=25,smtp.from=no-reply@baxter.com,smtp.ssl=false' \
        --set 'keycloak.okta.client_id=0oa31g0uno0Wgo6K0297' \
        --set 'keycloak.okta.client_secret=Wvo7J4iDznWc9I_iJQMKOlD5G_gDoUVykRPu9uAl' \
        --set 'keycloak.okta.base_url=https://iamtest.baxter.com' \
        --set 'keycloak.okta.hide_on_login_page=false' \
        --set 'keycloak.okta.disable_master_login=false' \
        --set 'global.customer.name=$customerName'
else
        mdap platform:install 4.1.7 \
        -n ns \
        --domain=$bdhpFqdn \
        --database=postgres \
        --set 'tags.beds=false' \
        --set 'tags.cdr=false' \
        --set 'tags.mirth=true' \
        --set 'tags.pumps=true' \
        --set 'bdhp-vernemq-pumps.service.mqtts.port=8883' \
        --set 'tags.wa-vitals=false' \
        --set 'tags.manual-adt=false' \
        --set 'tags.monitoring=true' \
        --set 'clamav.enabled=true' \
        --set 'bdhp-ntpd.enabled=true' \
        --set 'linkerd.enabled=true' \
        --set 'smtp.host=relays.baxter.com,smtp.port=25,smtp.from=no-reply@baxter.com,smtp.ssl=false' \
        --set 'keycloak.okta.client_id=0oa31g0uno0Wgo6K0297' \
        --set 'keycloak.okta.client_secret=Wvo7J4iDznWc9I_iJQMKOlD5G_gDoUVykRPu9uAl' \
        --set 'keycloak.okta.base_url=https://iamtest.baxter.com' \
        --set 'keycloak.okta.hide_on_login_page=false' \
        --set 'keycloak.okta.disable_master_login=false' \
        --set 'global.customer.name=$customerName'
fi

