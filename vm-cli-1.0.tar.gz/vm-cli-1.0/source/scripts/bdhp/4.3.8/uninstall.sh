#!/bin/bash

mdap uninstall baxter-bullseye-cqi-mdap -n ns --ignore-not-found

mdap uninstall baxter-bullseye-gateway-core-mdap  -n ns --ignore-not-found


 # Remove DeviceBridge
helm uninstall mdap -n ns
kubectl delete ns ns --ignore-not-found
kubectl delete sc redis-bdg --ignore-not-found
kubectl get crd | grep 'baxter\|cumulocity' | cut -d" " -f1 | xargs kubectl delete --ignore-not-found crd


# Uninstall Charts
helm uninstall bdhp-postgres-cluster -n postgres
helm uninstall cnpg -n cnpg-system
 # Remove namepsaces
kubectl delete ns postgres cnpg-system --ignore-not-found
 # Remove PVs
kubectl delete pv $(kubectl get pv | grep postgres | cut -d" " -f1) --ignore-not-found
 # Clean-up CRDs
kubectl get crd | grep 'postgresql' | cut -d" " -f1 | xargs kubectl delete --ignore-not-found crd
 # Remove Storage Class
kubectl delete sc postgresql-storage --ignore-not-found
 # remove data on disk
echo qwer1234 | sudo -S -i rm -Rf /srv/db/postgres/pvc*



 # Uninstall Charts
helm uninstall mongodb-cluster -n mongodb
helm uninstall mongodb-operators -n mongodb
 # Remove namepsaces
kubectl delete ns mongodb --ignore-not-found
 # Remove PVs
kubectl delete pv $(kubectl get pv | grep mongodb| cut -d" " -f1) --ignore-not-found
 # Clean-up CRDs
kubectl get crd | grep 'mongodb' | cut -d" " -f1 | xargs kubectl delete --ignore-not-found crd
 # Remove Storage Class
kubectl delete sc mongodb-storage --ignore-not-found
 # remove data on disk
echo qwer1234 | sudo -S -i rm -Rf /srv/db/mongodb/pvc*


 # Uninstall Charts
helm uninstall metallb -n metallb-system
 # Remove Namespace
kubectl delete ns metallb-system --ignore-not-found
 # Remove any CRDs
kubectl get crd | grep 'metallb' | cut -d" " -f1 | xargs kubectl delete --ignore-not-found crd



 # Uninstall Tenant
helm uninstall minio-tenant -n minio-tenant
 # Remove Tenant Namespace
kubectl delete ns minio-tenant --ignore-not-found
 # Remove Tenant PV
kubectl delete pv $(kubectl get pv | grep minio | cut -d" " -f1) --ignore-not-found
 # Uninstall Operator
helm uninstall minio-operator -n minio-operator
 # Remove Operator Namespace
kubectl delete ns minio-operator --ignore-not-found
 # Remove any CRDs
kubectl get crd | grep 'min\.io' | cut -d" " -f1 | xargs kubectl delete --ignore-not-found crd
 # Remove Storage Class
kubectl delete sc minio-storage-class --ignore-not-found



 # Uninstall Charts
helm uninstall loki -n monitoring
 # Remove Namespace
kubectl delete ns monitoring --ignore-not-found
 # Remove PV
kubectl delete pv $(kubectl get pv | grep monitoring | cut -d" " -f1) --ignore-not-found
 # Remove any CRDs
kubectl get crd | grep 'monitoring' | cut -d" " -f1 | xargs kubectl delete --ignore-not-found crd


 # Longhorn has a safety flag to prevent accidental deletion. Set that flag.
kubectl patch settings.longhorn.io deleting-confirmation-flag -n longhorn-system --type=json -p='[{"op":"replace","path":"/value","value":"true"}]'
 # Uninstall Charts
helm uninstall -n longhorn-system longhorn
 # Remove Namespace
kubectl delete ns longhorn-system
 # Remove any CRDs
kubectl get crd | grep 'longhorn' | cut -d" " -f1 | xargs kubectl delete  --ignore-not-found crd
echo qwer1234 | sudo -S -i rm -Rf /var/snap/microk8s/longhorn

 # Uninstall Charts
helm uninstall openebs -n openebs
 # Remove Namespace
kubectl delete ns openebs --ignore-not-found
 # Remove any CRDs
kubectl get crd | grep 'openebs\|storage' | cut -d" " -f1 | xargs kubectl delete  --ignore-not-found crd


echo -e "\e[4;33m Uninstalled Successfully.....\e[0m"


 # Install Postgres relational database (and the PostgreSQL Operator)
#lva install-postgres --yes



lva platform:install $bdhpVersion \
-n ns \
--domain=$bdhpFqdn \
--database=postgres \
--customer=$(hostname)-$(openssl rand -hex 4) \
--set 'tags.beds=false' \
--set 'tags.pumps=true' \
--set 'bdhp-vernemq-pumps.service.mqtts.port=8883' \
--set 'tags.wa-vitals=false' \
--set 'tags.manual-adt=false' \
--set 'tags.monitoring=true' \
--set 'clamav.enabled=true' \
--set 'bdhp-ntpd.enabled=true' \
--set 'bdhp-ntpd.nts.enabled=true' \
--set 'prometheus-blackbox-exporter.enabled=true' \
--set 'prometheus-postgres-exporter.enabled=true' \
--set 'prometheus-mongodb-exporter.enabled=false' \
--set 'prometheus-mysql-exporter.enabled=false' \
--set kube-prometheus-stack.prometheus.prometheusSpec.storageSpec.volumeClaimTemplate.spec.resources.requests.storage=20Gi \
--set kube-prometheus-stack.prometheus.prometheusSpec.retention=7d \
--set 'smtp.host=relays.baxter.com,smtp.port=25,smtp.from=no-reply@baxter.com,smtp.ssl=false' \
--set 'keycloak.okta.client_id=0oa31g0uno0Wgo6K0297' \
--set 'keycloak.okta.client_secret=Wvo7J4iDznWc9I_iJQMKOlD5G_gDoUVykRPu9uAl' \
--set 'keycloak.okta.base_url=https://iamtest.baxter.com' \
--set 'keycloak.okta.hide_on_login_page=false' \
--set 'keycloak.okta.disable_master_login=false' \
--set 'bdhp-vernemq-pumps.resources.requests.cpu=100m' \
--set 'rabbitmq.resources.requests.cpu=100m'

echo -e "\e[4;33m BDHP installed Successfully.....\e[0m"
