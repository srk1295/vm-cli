#!/bin/bash

mdap uninstall baxter-bullseye-cqi-mdap -n ns --ignore-not-found

mdap uninstall baxter-bullseye-gateway-core-mdap  -n ns --ignore-not-found


kubectl delete ns ns --ignore-not-found

 # Uninstall Charts
#helm uninstall bdhp-postgres-cluster -n postgres
#helm uninstall cnpg -n cnpg-system
 # Remove namepsaces
#kubectl delete ns postgres cnpg-system --ignore-not-found
 # remove the databases (with predicable names) from postgres
sudo lva psql "copy (select datname from pg_database where datname not in ('postgres', 'root', 'template0', 'template1')) to stdout" | xargs -L 1 -I {} lva psql "DROP DATABASE {} with (force);"

# also remove roles (logins)
sudo lva psql "copy (select rolname from pg_roles where rolname not like 'pg_%' and rolname not in ('postgres', 'root','streaming_replica')) to stdout" | xargs -L 1 -I {} lva psql "DROP ROLE {};"

echo -e "\e[31m psql cnpg-system dropping ..... Please wait...\e[0m"



 # OPTIONAL STEP
 # Install the Neo4j Graph database if you plan to install a guest application that requires it. (e.g. ICNET)
#lva install-neo4j --yes

 # OPTIONAL STEP
 # Install the MySQL database (and operator) if you plan to install a guest application that requires it. (e.g. ICNET, DoseIQ, Guardian)
#lva install-mysql --yes

## Environment Variable: Fully Qualified Domain Name
 ##
 ## This is what you'll type into your browser (https://<fqdn>) to use the web UI.
 ## which is something.stg.baxter.com
#bdhpFqdn=$(hostname).stg.baxter.com
 ## Environment Variable: Version of DeviceBridge to install
 ##
bdhpVersion=4.3.8
 # Install DeviceBridge

 # Note: since we are deploying both Pump and Bed Verne, we configure the pump verne to list on port 8883
 # Further Note: we don't expect Novum pumps to use 8884 in production! This is just a quick setup thing.
 # Additionally: CPU requests for Pump Verne and Rabbit are being overridden to reduce the CPU required for
        lva platform:install $bdhpVersion \
        -n ns \
        --domain=$bdhpFqdn \
        --database=postgres \
        --customer=$(hostname)-$(openssl rand -hex 4) \
        --set 'tags.beds=false' \
        --set 'tags.pumps=true' \
        --set 'bdhp-vernemq-pumps.service.mqtts.port=8883' \
        --set 'tags.wa-vitals=false' \
        --set 'tags.manual-adt=false' \
        --set 'tags.monitoring=true' \
        --set 'clamav.enabled=true' \
        --set 'bdhp-ntpd.enabled=true' \
        --set 'bdhp-ntpd.nts.enabled=true' \
        --set 'prometheus-blackbox-exporter.enabled=true' \
        --set 'prometheus-postgres-exporter.enabled=true' \
        --set 'prometheus-mongodb-exporter.enabled=false' \
        --set 'prometheus-mysql-exporter.enabled=false' \
        --set kube-prometheus-stack.prometheus.prometheusSpec.storageSpec.volumeClaimTemplate.spec.resources.requests.storage=20Gi \
        --set kube-prometheus-stack.prometheus.prometheusSpec.retention=7d \
        --set 'smtp.host=relays.baxter.com,smtp.port=25,smtp.from=no-reply@baxter.com,smtp.ssl=false' \
        --set 'keycloak.okta.client_id=0oa31g0uno0Wgo6K0297' \
        --set 'keycloak.okta.client_secret=Wvo7J4iDznWc9I_iJQMKOlD5G_gDoUVykRPu9uAl' \
        --set 'keycloak.okta.base_url=https://iamtest.baxter.com' \
        --set 'keycloak.okta.hide_on_login_page=false' \
        --set 'keycloak.okta.disable_master_login=false' \
        --set 'bdhp-vernemq-pumps.resources.requests.cpu=100m' \
        --set 'rabbitmq.resources.requests.cpu=100m'
