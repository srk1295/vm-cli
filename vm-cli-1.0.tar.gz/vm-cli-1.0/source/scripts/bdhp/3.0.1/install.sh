/appliance/bin/setup-db-storage /dev/sdb
/appliance/install_microk8s.sh --dns-servers "10.251.210.129,10.251.208.129"
/appliance/bin/change_metallb_ip
/appliance/install_database.sh --postgres
/appliance/pull_mdap_platform_charts.sh 3.0.1
mdap configure:postgres -n ns
sleep 2
mdapFqdn=$(hostname).stg.baxter.com
mdapVersion=3.1.0
mdap platform:install -n ns $mdapVersion --set "keycloak.countryOfDeployment=US" --domain=$mdapFqdn --database=postgresql
mdap install -n ns "mdap-language-library-helm:1.0.1"
mdap install -n ns "mdap-iqecs-helm:3.0.1"
