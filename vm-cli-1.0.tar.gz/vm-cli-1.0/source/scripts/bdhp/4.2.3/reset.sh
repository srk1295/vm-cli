kubectl delete namespace ns
kubectl delete ns postgres cnpg-system --ignore-not-found
# Install PostgreSQL database on the appliance
sudo lva install-postgres --force

mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter1.crt -n ns
mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter2.crt -n ns
mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter3.crt -n ns

#bdhpFqdn=$(hostname).stg.baxter.com
bdhpVersion=4.2.3

mdap platform:install $bdhpVersion -n ns --domain=$bdhpFqdn  --database=postgresql --set 'tags.pumps=true' --set 'tags.mirth=true' --set 'bdhp-ntpd.enabled=true' --set 'linkerd.enabled=true' --set 'clamav.enabled=true' --set 'tags.monitoring=true' --set 'keycloak.okta.client_id=0oa31g0uno0Wgo6K0297' --set 'keycloak.okta.client_secret=Wvo7J4iDznWc9I_iJQMKOlD5G_gDoUVykRPu9uAl' --set 'keycloak.okta.base_url=https://iamtest.baxter.com' --set 'keycloak.okta.hide_on_login_page=false' --set 'keycloak.okta.disable_master_login=false' --set 'smtp.host=relays.baxter.com' --set 'smtp.port=25' --set 'smtp.from=no-reply@baxter.com' --set 'smtp.ssl=false' --set 'global.customer.name=BDHPdevelopmenttestCumulocity'
