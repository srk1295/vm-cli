# As root, run automatic set-up of attached database storage disk on 2nd device attached to SCSI disk controller
sudo lva setup-m8s-storage /dev/sdb --force
 
# IF VM IS HOSTED ON BAXTER NETWORK (SO GLENDALE SERVER FOR EXAMPLE), USE THIS. Otherwise change based on your hypervisor or laptop location.
sudo lva install-microk8s --dns-servers "10.251.210.129,10.251.208.129"
# Assign Metallb IP Address
sudo lva change-metallb-ip "$(ip addr | grep eth0 | grep inet | cut -d" " -f6 | cut -d"/" -f1)"

# As root, run automatic set-up of attached Postgres storage disk on 3rd device attached to SCSI disk controller
sudo lva setup-db-storage /dev/sdc postgres --force

# As root, run automatic set-up of attached backups storage disk on 4th device attached to SCSI disk controller
sudo lva setup-backups-storage /dev/sdd --force

# Install PostgreSQL database on the appliance
sudo lva install-postgres --force

mdap trust-store:add /usr/local/share/ca-certificates/baxter-proxy.crt -n ns

mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter1.crt -n ns
mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter2.crt -n ns
mdap trust-store:add /usr/share/pki/ca-trust-source/anchors/baxter3.crt -n ns

bdhpVersion=4.2.3

mdap platform:install $bdhpVersion -n ns --domain=$bdhpFqdn  --database=postgresql --set 'tags.pumps=true' --set 'tags.mirth=true' --set 'bdhp-ntpd.enabled=true' --set 'linkerd.enabled=true' --set 'clamav.enabled=true' --set 'tags.monitoring=true' --set 'keycloak.okta.client_id=0oa31g0uno0Wgo6K0297' --set 'keycloak.okta.client_secret=Wvo7J4iDznWc9I_iJQMKOlD5G_gDoUVykRPu9uAl' --set 'keycloak.okta.base_url=https://iamtest.baxter.com' --set 'keycloak.okta.hide_on_login_page=false' --set 'keycloak.okta.disable_master_login=false' --set 'smtp.host=relays.baxter.com' --set 'smtp.port=25' --set 'smtp.from=no-reply@baxter.com' --set 'smtp.ssl=false' --set 'global.customer.name=BDHPdevelopmenttestCumulocity'

